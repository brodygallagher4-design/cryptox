# CryptoxCore

Cryptocurrency trading platform built with Node.js, Express, SQLite, and React.

## Setup

```bash
npm install
node server.js
```

Server runs on port 3000.

## Structure

```
cryptoxcore/
├── server.js                    # Express backend + API routes
├── package.json
├── .gitignore
└── public/
    ├── index.html               # Landing page
    ├── login.html               # Login page
    ├── register.html            # Signup page
    ├── forgot-password.html     # Password reset flow
    ├── dashboard.html           # Protected dashboard SPA
    ├── admin.html               # Admin panel
    ├── css/
    │   └── auth.css             # Shared auth styles
    └── js/
        └── auth-shared.js       # Shared auth helpers
```

## Routes

| Route | Page |
|-------|------|
| `/` | Landing page |
| `/login` | Login |
| `/register` | Sign up |
| `/forgot-password` | Password reset |
| `/dashboard` | Dashboard (protected) |
| `/wallet` | Wallet (protected) |
| `/exchange` | Exchange (protected) |
| `/admin` | Admin panel |
