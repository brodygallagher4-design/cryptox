const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Database = require('better-sqlite3');
const path = require('path');
const crypto = require('crypto');
const fetch = (...args) => import('node-fetch').then(({default: f}) => f(...args));

// Load .env
const envPath = path.join(__dirname, '.env');
try {
  const envContent = require('fs').readFileSync(envPath, 'utf8');
  envContent.split('\n').forEach(line => {
    const [key, ...vals] = line.split('=');
    if (key && vals.length) process.env[key.trim()] = vals.join('=').trim();
  });
  console.log('[ENV] Loaded .env file');
} catch (e) {
  console.log('[ENV] No .env file found, using environment variables');
}

const app = express();
app.set('trust proxy', 1); // Trust Nginx proxy for correct client IP
const PORT = 3001;
const XAF_RATE = 530;

// Persistent JWT Secret — survives restarts so tokens stay valid
const JWT_SECRET = (() => {
  if (process.env.JWT_SECRET) return process.env.JWT_SECRET;
  const secret = 'cxc_' + crypto.randomBytes(64).toString('hex');
  try {
    const envFile = path.join(__dirname, '.env');
    const fs = require('fs');
    let content = '';
    try { content = fs.readFileSync(envFile, 'utf8'); } catch(e) {}
    if (!content.includes('JWT_SECRET=')) {
      fs.appendFileSync(envFile, '\nJWT_SECRET=' + secret + '\n');
      console.log('[SECURITY] Generated and saved persistent JWT secret');
    }
    return secret;
  } catch(e) { return secret; }
})();

// Binance API config
const BINANCE_KEY = process.env.BINANCE_API_KEY || '';
const BINANCE_SECRET = process.env.BINANCE_API_SECRET || '';
const BINANCE_BASE = 'https://api.binance.com';

function binanceSign(queryString) {
  return crypto.createHmac('sha256', BINANCE_SECRET).update(queryString).digest('hex');
}

async function binanceRequest(endpoint, params = {}, method = 'GET') {
  const timestamp = Date.now();
  params.timestamp = timestamp;
  const queryString = Object.entries(params).map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&');
  const signature = binanceSign(queryString);
  const url = `${BINANCE_BASE}${endpoint}?${queryString}&signature=${signature}`;
  const opts = {
    method,
    headers: { 'X-MBX-APIKEY': BINANCE_KEY }
  };
  const res = await fetch(url, opts);
  const data = await res.json();
  if (data.code && data.code !== 200) throw new Error(data.msg || 'Binance API error');
  return data;
}

// Supported networks per coin
const COIN_NETWORKS = {
  BTC: [{network:'BTC',name:'Bitcoin',minDeposit:'0.00001'},{network:'BNB',name:'BEP20 (BSC)',minDeposit:'0.00001'}],
  ETH: [{network:'ETH',name:'Ethereum (ERC20)',minDeposit:'0.001'},{network:'BNB',name:'BEP20 (BSC)',minDeposit:'0.0001'}],
  BNB: [{network:'BNB',name:'BNB Smart Chain',minDeposit:'0.001'},{network:'ETH',name:'ERC20',minDeposit:'0.001'}],
  SOL: [{network:'SOL',name:'Solana',minDeposit:'0.01'}],
  XRP: [{network:'XRP',name:'Ripple',minDeposit:'0.1'}],
  ADA: [{network:'ADA',name:'Cardano',minDeposit:'1'}],
  DOGE: [{network:'DOGE',name:'Dogecoin',minDeposit:'5'}],
  AVAX: [{network:'AVAX',name:'Avalanche C-Chain',minDeposit:'0.01'}],
  DOT: [{network:'DOT',name:'Polkadot',minDeposit:'0.1'}],
  LINK: [{network:'ETH',name:'Ethereum (ERC20)',minDeposit:'0.1'},{network:'BNB',name:'BEP20 (BSC)',minDeposit:'0.01'}],
  LTC: [{network:'LTC',name:'Litecoin',minDeposit:'0.001'}],
  USDT: [{network:'ETH',name:'ERC20',minDeposit:'1'},{network:'TRX',name:'TRC20',minDeposit:'1'},{network:'BNB',name:'BEP20 (BSC)',minDeposit:'1'}],
  UNI: [{network:'ETH',name:'Ethereum (ERC20)',minDeposit:'0.1'}],
  TRX: [{network:'TRX',name:'Tron',minDeposit:'1'}],
};

// ══════════════════════════════════════
// DATABASE SETUP
// ══════════════════════════════════════
const db = new Database(path.join(__dirname, 'cryptoxcore.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    phone TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    balance_xaf REAL DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now')),
    last_login TEXT,
    is_verified INTEGER DEFAULT 0,
    tfa_enabled INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS portfolio (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    coin_id TEXT NOT NULL,
    quantity REAL DEFAULT 0,
    UNIQUE(user_id, coin_id),
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    type TEXT NOT NULL,
    coin_id TEXT,
    coin_symbol TEXT,
    quantity REAL,
    price_usd REAL,
    amount_xaf REAL,
    method TEXT,
    phone TEXT,
    address TEXT,
    network TEXT,
    status TEXT DEFAULT 'completed',
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    token_hash TEXT NOT NULL,
    ip_address TEXT,
    user_agent TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    expires_at TEXT NOT NULL,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS password_resets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    code TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    used INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS login_attempts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL,
    ip_address TEXT,
    success INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
  );
`);

// Prepared statements for performance
const stmts = {
  findUserByEmail: db.prepare('SELECT * FROM users WHERE email = ?'),
  findUserById: db.prepare('SELECT id, full_name, email, phone, balance_xaf, created_at, is_verified, tfa_enabled FROM users WHERE id = ?'),
  createUser: db.prepare('INSERT INTO users (full_name, email, phone, password_hash) VALUES (?, ?, ?, ?)'),
  updateBalance: db.prepare('UPDATE users SET balance_xaf = ? WHERE id = ?'),
  updateLastLogin: db.prepare("UPDATE users SET last_login = datetime('now') WHERE id = ?"),
  getPortfolio: db.prepare('SELECT coin_id, quantity FROM portfolio WHERE user_id = ? AND quantity > 0'),
  upsertPortfolio: db.prepare('INSERT INTO portfolio (user_id, coin_id, quantity) VALUES (?, ?, ?) ON CONFLICT(user_id, coin_id) DO UPDATE SET quantity = quantity + ?'),
  setPortfolio: db.prepare('INSERT INTO portfolio (user_id, coin_id, quantity) VALUES (?, ?, ?) ON CONFLICT(user_id, coin_id) DO UPDATE SET quantity = ?'),
  getTransactions: db.prepare('SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 100'),
  addTransaction: db.prepare('INSERT INTO transactions (user_id, type, coin_id, coin_symbol, quantity, price_usd, amount_xaf, method, phone, address, network, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'),
};

// ══════════════════════════════════════
// MIDDLEWARE — SECURITY HARDENED
// ══════════════════════════════════════

// Security headers (helmet-equivalent without extra dependency)
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://unpkg.com https://cdnjs.cloudflare.com https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https:; connect-src 'self' https://api.coingecko.com https://api.binance.com https://*.telegram.org;");
  res.removeHeader('X-Powered-By');
  next();
});

// CORS — restrict to your domain only
const ALLOWED_ORIGINS = ['https://cryptoxcore.com', 'https://www.cryptoxcore.com', 'https://fauscrypto.com', 'https://www.fauscrypto.com'];
app.use(cors({
  origin: (origin, cb) => {
    if (!origin || ALLOWED_ORIGINS.includes(origin)) cb(null, true);
    else cb(new Error('CORS blocked'));
  },
  credentials: true
}));

// Limit request body size to prevent DoS
app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Input sanitization helper — strips HTML/script tags
function sanitize(str) {
  if (typeof str !== 'string') return str;
  return str.replace(/[<>"'`;(){}]/g, '').trim().slice(0, 500);
}

// IP extraction helper (behind nginx proxy)
function getIP(req) {
  return req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip || 'unknown';
}

// Security event logger
function secLog(event, details) {
  const ts = new Date().toISOString();
  console.log(`[SECURITY] ${ts} | ${event} | ${JSON.stringify(details)}`);
}

// Auth middleware
const auth = (req, res, next) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'No token provided' });
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const user = stmts.findUserById.get(decoded.userId);
    if (!user) return res.status(401).json({ error: 'User not found' });
    req.user = user;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid token' });
  }
};

// Rate limiter (improved with IP tracking)
const rateLimit = {};
const failedLogins = {};
const limiter = (maxReqs, windowMs) => (req, res, next) => {
  const ip = getIP(req);
  const key = ip + req.path;
  const now = Date.now();
  if (!rateLimit[key]) rateLimit[key] = [];
  rateLimit[key] = rateLimit[key].filter(t => t > now - windowMs);
  if (rateLimit[key].length >= maxReqs) {
    secLog('RATE_LIMIT', { ip, path: req.path });
    return res.status(429).json({ error: 'Too many requests. Try again later.' });
  }
  rateLimit[key].push(now);
  next();
};

// Brute force protection — lock account after 5 failed logins
function checkBruteForce(ip, email) {
  const key = ip + ':' + email;
  const now = Date.now();
  if (!failedLogins[key]) failedLogins[key] = [];
  failedLogins[key] = failedLogins[key].filter(t => t > now - 900000); // 15 min window
  return failedLogins[key].length >= 5;
}
function recordFailedLogin(ip, email) {
  const key = ip + ':' + email;
  if (!failedLogins[key]) failedLogins[key] = [];
  failedLogins[key].push(Date.now());
}

// Clean up rate limit memory every 10 minutes
setInterval(() => {
  const now = Date.now();
  Object.keys(rateLimit).forEach(k => {
    rateLimit[k] = rateLimit[k].filter(t => t > now - 600000);
    if (!rateLimit[k].length) delete rateLimit[k];
  });
  Object.keys(failedLogins).forEach(k => {
    failedLogins[k] = failedLogins[k].filter(t => t > now - 900000);
    if (!failedLogins[k].length) delete failedLogins[k];
  });
}, 600000);

// ══════════════════════════════════════
// CRYPTO PRICE CACHE
// ══════════════════════════════════════
let coinCache = [];
let lastFetch = 0;
const COIN_IDS = "bitcoin,ethereum,binancecoin,solana,ripple,cardano,dogecoin,avalanche-2,polkadot,chainlink,litecoin,tether,uniswap,tron";

async function fetchPrices() {
  try {
    const res = await fetch(`https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=${COIN_IDS}&order=market_cap_desc&per_page=15&page=1&sparkline=true&price_change_percentage=1h%2C24h%2C7d`);
    if (!res.ok) throw new Error('CoinGecko API error');
    coinCache = await res.json();
    lastFetch = Date.now();
    console.log(`[PRICES] Updated ${coinCache.length} coins`);
  } catch (e) {
    console.error('[PRICES] Fetch failed:', e.message);
  }
}

// Fetch prices every 30 seconds
fetchPrices();
setInterval(fetchPrices, 30000);

function getCoinPrice(coinId) {
  const coin = coinCache.find(c => c.id === coinId);
  return coin ? coin.current_price : null;
}

// ══════════════════════════════════════
// AUTH ROUTES
// ══════════════════════════════════════

// REGISTER
app.post('/api/auth/register', limiter(5, 60000), (req, res) => {
  try {
    const { fullName, email, phone, password } = req.body;
    const ip = getIP(req);
    
    // Sanitize inputs
    const cleanName = sanitize(fullName);
    const cleanEmail = email ? email.toLowerCase().trim().slice(0, 254) : '';
    const cleanPhone = phone ? phone.replace(/[^0-9+]/g, '').slice(0, 15) : '';
    
    // Validation
    if (!cleanName || cleanName.length < 2) return res.status(400).json({ error: 'Full name is required (min 2 characters)' });
    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.') || cleanEmail.length < 5) return res.status(400).json({ error: 'Valid email is required' });
    if (!cleanPhone || cleanPhone.length < 9) return res.status(400).json({ error: 'Valid phone number is required (min 9 digits)' });
    if (!password || password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
    if (password.length > 128) return res.status(400).json({ error: 'Password too long' });
    
    // Check if email exists
    const existing = stmts.findUserByEmail.get(cleanEmail);
    if (existing) return res.status(409).json({ error: 'An account with this email already exists' });
    
    // Hash password
    const hash = bcrypt.hashSync(password, 12);
    
    // Create user
    const result = stmts.createUser.run(cleanName, cleanEmail, cleanPhone, hash);
    const user = stmts.findUserById.get(result.lastInsertRowid);
    
    // Generate token
    const token = jwt.sign({ userId: user.id, iat: Math.floor(Date.now()/1000) }, JWT_SECRET, { expiresIn: '7d' });
    
    secLog('REGISTER_OK', { ip, email: cleanEmail, userId: user.id });
    res.json({ token, user: { id: user.id, fullName: user.full_name, email: user.email, phone: user.phone, balance: user.balance_xaf, joined: user.created_at } });
    notifyUser(user.id, '🎉 <b>Welcome to CryptoxCore!</b>\n\nYour account has been created.\nStart trading crypto with Mobile Money!');
  } catch (e) {
    console.error('[AUTH] Register error:', e);
    res.status(500).json({ error: 'Registration failed. Please try again.' });
  }
});

// LOGIN
app.post('/api/auth/login', limiter(10, 60000), (req, res) => {
  try {
    const { email, password } = req.body;
    const ip = getIP(req);
    
    if (!email || !password) return res.status(400).json({ error: 'Email and password are required' });
    
    const cleanEmail = sanitize(email).toLowerCase();
    
    // Check brute force lockout
    if (checkBruteForce(ip, cleanEmail)) {
      secLog('BRUTE_FORCE_BLOCKED', { ip, email: cleanEmail });
      return res.status(429).json({ error: 'Account temporarily locked due to too many failed attempts. Try again in 15 minutes.' });
    }
    
    const user = stmts.findUserByEmail.get(cleanEmail);
    if (!user) {
      recordFailedLogin(ip, cleanEmail);
      secLog('LOGIN_FAIL_NO_USER', { ip, email: cleanEmail });
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    
    const valid = bcrypt.compareSync(password, user.password_hash);
    if (!valid) {
      recordFailedLogin(ip, cleanEmail);
      secLog('LOGIN_FAIL_BAD_PW', { ip, email: cleanEmail, userId: user.id });
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    
    // Update last login
    stmts.updateLastLogin.run(user.id);
    
    // Generate token
    const token = jwt.sign({ userId: user.id, iat: Math.floor(Date.now()/1000) }, JWT_SECRET, { expiresIn: '7d' });
    
    secLog('LOGIN_OK', { ip, email: cleanEmail, userId: user.id });
    res.json({ token, user: { id: user.id, fullName: user.full_name, email: user.email, phone: user.phone, balance: user.balance_xaf, joined: user.created_at } });
    notifyUser(user.id, '🔐 <b>Security Alert</b>\n\nNew login detected on your account.\nIP: ' + ip + '\nTime: ' + new Date().toISOString().replace('T',' ').slice(0,19) + ' UTC\n\nIf this was not you, please secure your account.');
  } catch (e) {
    console.error('[AUTH] Login error:', e);
    res.status(500).json({ error: 'Login failed. Please try again.' });
  }
});

// FORGOT PASSWORD - Request reset code
app.post('/api/auth/forgot-password', limiter(3, 60000), (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email is required' });
    
    const user = stmts.findUserByEmail.get(email.toLowerCase().trim());
    if (!user) {
      // Return success anyway to prevent email enumeration
      const parts = email.split('@');
      const masked = parts[0].substring(0, 2) + '***@' + (parts[1] || 'email.com');
      return res.json({ message: 'If an account exists, a reset code has been sent.', maskedEmail: masked });
    }
    
    // Generate 6-digit code (cryptographically secure)
    const code = crypto.randomInt(100000, 999999).toString();
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString();
    
    // Invalidate previous codes
    db.prepare('UPDATE password_resets SET used = 1 WHERE user_id = ? AND used = 0').run(user.id);
    db.prepare('INSERT INTO password_resets (user_id, code, expires_at) VALUES (?, ?, ?)').run(user.id, code, expiresAt);
    
    console.log(`[AUTH] Password reset requested for ${email}, code: ${code}`);
    
    // Notify via Telegram
    notifyUser(user.id, '🔑 <b>Password Reset Code</b>\n\nYour code is: <code>' + code + '</code>\n\nExpires in 15 minutes.\nIf you did not request this, ignore this message.');
    
    const parts = email.split('@');
    const masked = parts[0].substring(0, 2) + '***@' + parts[1];
    res.json({ message: 'Reset code sent', maskedEmail: masked });
  } catch (e) {
    console.error('[AUTH] Forgot password error:', e);
    res.status(500).json({ error: 'Failed to process request' });
  }
});

// VERIFY RESET CODE
app.post('/api/auth/verify-reset-code', limiter(5, 60000), (req, res) => {
  try {
    const { email, code } = req.body;
    if (!email || !code) return res.status(400).json({ error: 'Email and code are required' });
    
    const user = stmts.findUserByEmail.get(email.toLowerCase().trim());
    if (!user) return res.status(400).json({ error: 'Invalid request' });
    
    const reset = db.prepare('SELECT * FROM password_resets WHERE user_id = ? AND code = ? AND used = 0 ORDER BY created_at DESC LIMIT 1').get(user.id, code);
    if (!reset) return res.status(400).json({ error: 'Invalid or expired code' });
    
    if (new Date(reset.expires_at) < new Date()) {
      db.prepare('UPDATE password_resets SET used = 1 WHERE id = ?').run(reset.id);
      return res.status(400).json({ error: 'Code expired. Please request a new one.' });
    }
    
    // Generate reset token
    const resetToken = crypto.randomBytes(32).toString('hex');
    db.prepare('UPDATE password_resets SET used = 1 WHERE id = ?').run(reset.id);
    const tokenExpiry = new Date(Date.now() + 10 * 60 * 1000).toISOString();
    db.prepare('INSERT INTO password_resets (user_id, code, expires_at) VALUES (?, ?, ?)').run(user.id, 'TOKEN:' + resetToken, tokenExpiry);
    
    res.json({ resetToken, message: 'Code verified' });
  } catch (e) {
    console.error('[AUTH] Verify reset error:', e);
    res.status(500).json({ error: 'Verification failed' });
  }
});

// RESET PASSWORD
app.post('/api/auth/reset-password', limiter(3, 60000), (req, res) => {
  try {
    const { email, resetToken, newPassword } = req.body;
    if (!email || !resetToken || !newPassword) return res.status(400).json({ error: 'All fields required' });
    if (newPassword.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
    
    const user = stmts.findUserByEmail.get(email.toLowerCase().trim());
    if (!user) return res.status(400).json({ error: 'Invalid request' });
    
    const reset = db.prepare('SELECT * FROM password_resets WHERE user_id = ? AND code = ? AND used = 0 ORDER BY created_at DESC LIMIT 1').get(user.id, 'TOKEN:' + resetToken);
    if (!reset) return res.status(400).json({ error: 'Invalid or expired reset session' });
    
    if (new Date(reset.expires_at) < new Date()) {
      db.prepare('UPDATE password_resets SET used = 1 WHERE id = ?').run(reset.id);
      return res.status(400).json({ error: 'Session expired. Please start over.' });
    }
    
    const hash = bcrypt.hashSync(newPassword, 12);
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, user.id);
    db.prepare('UPDATE password_resets SET used = 1 WHERE user_id = ?').run(user.id);
    
    console.log(`[AUTH] Password reset completed for ${email}`);
    notifyUser(user.id, '✅ <b>Password Changed</b>\n\nYour password was successfully reset.\nTime: ' + new Date().toISOString().replace('T',' ').slice(0,19) + ' UTC\n\nIf this was not you, contact support immediately.');
    
    res.json({ message: 'Password reset successfully. You can now sign in.' });
  } catch (e) {
    console.error('[AUTH] Reset password error:', e);
    res.status(500).json({ error: 'Password reset failed' });
  }
});

// GET CURRENT USER
app.get('/api/auth/me', auth, (req, res) => {
  const portfolio = stmts.getPortfolio.all(req.user.id);
  const portObj = {};
  portfolio.forEach(p => { portObj[p.coin_id] = p.quantity; });
  
  res.json({
    user: {
      id: req.user.id,
      fullName: req.user.full_name,
      email: req.user.email,
      phone: req.user.phone,
      balance: req.user.balance_xaf,
      joined: req.user.created_at,
      verified: req.user.is_verified,
      tfa: req.user.tfa_enabled
    },
    portfolio: portObj
  });
});

// ══════════════════════════════════════
// MARKET DATA ROUTES
// ══════════════════════════════════════
app.get('/api/coins', (req, res) => {
  res.json({ coins: coinCache, updated: lastFetch });
});

// ══════════════════════════════════════
// WALLET ROUTES
// ══════════════════════════════════════

// DEPOSIT XAF
app.post('/api/wallet/deposit', auth, limiter(10, 60000), (req, res) => {
  try {
    const { amount, method, phone } = req.body;
    const amountNum = parseInt(amount);
    const cleanPhone = phone ? phone.replace(/[^0-9+]/g, '').slice(0, 15) : '';
    const ip = getIP(req);
    
    if (!amountNum || amountNum < 100) return res.status(400).json({ error: 'Minimum deposit is 100 XAF' });
    if (amountNum > 10000000) return res.status(400).json({ error: 'Maximum deposit is 10,000,000 XAF' });
    if (!cleanPhone || cleanPhone.length < 9) return res.status(400).json({ error: 'Valid phone number required' });
    if (!['mtn', 'orange'].includes(method)) return res.status(400).json({ error: 'Invalid payment method' });
    
    // Update balance
    const newBal = req.user.balance_xaf + amountNum;
    stmts.updateBalance.run(newBal, req.user.id);
    
    // Record transaction
    stmts.addTransaction.run(req.user.id, 'deposit', null, null, null, null, amountNum, method === 'mtn' ? 'MTN Mobile Money' : 'Orange Money', cleanPhone, null, null, 'completed');
    
    secLog('DEPOSIT', { ip, userId: req.user.id, amount: amountNum, method, phone: cleanPhone });
    res.json({ balance: newBal, message: `${amountNum.toLocaleString()} XAF deposited successfully` });
  } catch (e) {
    console.error('[WALLET] Deposit error:', e);
    res.status(500).json({ error: 'Deposit failed' });
  }
});

// WITHDRAW XAF
app.post('/api/wallet/withdraw', auth, limiter(5, 60000), (req, res) => {
  try {
    const { amount, method, phone } = req.body;
    const amountNum = parseInt(amount);
    const cleanPhone = phone ? phone.replace(/[^0-9+]/g, '').slice(0, 15) : '';
    const ip = getIP(req);
    
    if (!amountNum || amountNum < 500) return res.status(400).json({ error: 'Minimum withdrawal is 500 XAF' });
    if (amountNum > req.user.balance_xaf) return res.status(400).json({ error: 'Insufficient balance' });
    if (!cleanPhone || cleanPhone.length < 9) return res.status(400).json({ error: 'Valid phone number required' });
    
    const newBal = req.user.balance_xaf - amountNum;
    stmts.updateBalance.run(newBal, req.user.id);
    
    stmts.addTransaction.run(req.user.id, 'withdraw', null, null, null, null, amountNum, method === 'mtn' ? 'MTN Mobile Money' : 'Orange Money', cleanPhone, null, null, 'completed');
    
    secLog('WITHDRAW', { ip, userId: req.user.id, amount: amountNum, method, phone: cleanPhone });
    notifyUser(req.user.id, '💸 <b>XAF Withdrawal Processed!</b>\n\nAmount: <b>' + Math.round(amountNum).toLocaleString() + ' XAF</b>\nTo: +237 ' + (cleanPhone || '') + '\nMethod: ' + (method || 'Mobile Money') + '\nStatus: ✅ Sent');
    res.json({ balance: newBal, message: `${amountNum.toLocaleString()} XAF withdrawn successfully` });
  } catch (e) {
    console.error('[WALLET] Withdraw error:', e);
    res.status(500).json({ error: 'Withdrawal failed' });
  }
});

// ══════════════════════════════════════
// EXCHANGE ROUTES
// ══════════════════════════════════════

// BUY CRYPTO
app.post('/api/exchange/buy', auth, limiter(15, 60000), (req, res) => {
  try {
    const { coinId, quantity } = req.body;
    const qty = parseFloat(quantity);
    
    if (!coinId || !qty || qty <= 0) return res.status(400).json({ error: 'Invalid coin or quantity' });
    
    const price = getCoinPrice(coinId);
    if (!price) return res.status(400).json({ error: 'Price not available. Try again.' });
    
    const costXAF = qty * price * XAF_RATE;
    if (costXAF > req.user.balance_xaf) return res.status(400).json({ error: 'Insufficient XAF balance' });
    
    const coin = coinCache.find(c => c.id === coinId);
    const symbol = coin ? coin.symbol.toUpperCase() : coinId.slice(0, 4).toUpperCase();
    
    // Deduct XAF
    const newBal = req.user.balance_xaf - costXAF;
    stmts.updateBalance.run(newBal, req.user.id);
    
    // Add crypto to portfolio
    stmts.upsertPortfolio.run(req.user.id, coinId, qty, qty);
    
    // Record transaction
    stmts.addTransaction.run(req.user.id, 'buy', coinId, symbol, qty, price, costXAF, null, null, null, null, 'completed');
    
    // Get updated portfolio
    const portfolio = stmts.getPortfolio.all(req.user.id);
    const portObj = {};
    portfolio.forEach(p => { portObj[p.coin_id] = p.quantity; });
    
    console.log(`[EXCHANGE] Buy: ${qty} ${symbol} @ $${price} by user ${req.user.id}`);
    res.json({ balance: newBal, portfolio: portObj, message: `Bought ${qty} ${symbol} for ${Math.round(costXAF).toLocaleString()} XAF` });
  } catch (e) {
    console.error('[EXCHANGE] Buy error:', e);
    res.status(500).json({ error: 'Purchase failed' });
  }
});

// SELL CRYPTO
app.post('/api/exchange/sell', auth, limiter(15, 60000), (req, res) => {
  try {
    const { coinId, quantity } = req.body;
    const qty = parseFloat(quantity);
    
    if (!coinId || !qty || qty <= 0) return res.status(400).json({ error: 'Invalid coin or quantity' });
    
    const price = getCoinPrice(coinId);
    if (!price) return res.status(400).json({ error: 'Price not available' });
    
    // Check holdings
    const holding = stmts.getPortfolio.all(req.user.id).find(p => p.coin_id === coinId);
    if (!holding || holding.quantity < qty) return res.status(400).json({ error: 'Insufficient crypto balance' });
    
    const coin = coinCache.find(c => c.id === coinId);
    const symbol = coin ? coin.symbol.toUpperCase() : coinId.slice(0, 4).toUpperCase();
    const earnXAF = qty * price * XAF_RATE;
    
    // Add XAF
    const newBal = req.user.balance_xaf + earnXAF;
    stmts.updateBalance.run(newBal, req.user.id);
    
    // Remove crypto
    const newQty = holding.quantity - qty;
    stmts.setPortfolio.run(req.user.id, coinId, newQty, newQty);
    
    stmts.addTransaction.run(req.user.id, 'sell', coinId, symbol, qty, price, earnXAF, null, null, null, null, 'completed');
    
    const portfolio = stmts.getPortfolio.all(req.user.id);
    const portObj = {};
    portfolio.forEach(p => { portObj[p.coin_id] = p.quantity; });
    
    console.log(`[EXCHANGE] Sell: ${qty} ${symbol} @ $${price} by user ${req.user.id}`);
    res.json({ balance: newBal, portfolio: portObj, message: `Sold ${qty} ${symbol} for ${Math.round(earnXAF).toLocaleString()} XAF` });
  } catch (e) {
    console.error('[EXCHANGE] Sell error:', e);
    res.status(500).json({ error: 'Sale failed' });
  }
});

// CRYPTO WITHDRAW
app.post('/api/exchange/crypto-withdraw', auth, (req, res) => {
  try {
    const { coinId, quantity, address, network } = req.body;
    const qty = parseFloat(quantity);
    
    if (!coinId || !qty || qty <= 0) return res.status(400).json({ error: 'Invalid quantity' });
    if (!address || address.length < 10) return res.status(400).json({ error: 'Invalid wallet address' });
    
    const holding = stmts.getPortfolio.all(req.user.id).find(p => p.coin_id === coinId);
    if (!holding || holding.quantity < qty) return res.status(400).json({ error: 'Insufficient crypto balance' });
    
    const coin = coinCache.find(c => c.id === coinId);
    const symbol = coin ? coin.symbol.toUpperCase() : coinId.slice(0, 4).toUpperCase();
    const price = getCoinPrice(coinId) || 0;
    
    const newQty = holding.quantity - qty;
    stmts.setPortfolio.run(req.user.id, coinId, newQty, newQty);
    
    stmts.addTransaction.run(req.user.id, 'crypto_wd', coinId, symbol, qty, price, qty * price * XAF_RATE, null, null, address, network || 'ERC20', 'completed');
    
    const portfolio = stmts.getPortfolio.all(req.user.id);
    const portObj = {};
    portfolio.forEach(p => { portObj[p.coin_id] = p.quantity; });
    
    console.log(`[EXCHANGE] Crypto withdraw: ${qty} ${symbol} to ${address.slice(0, 12)}... by user ${req.user.id}`);
    notifyUser(req.user.id, '📤 <b>Crypto Withdrawal Sent!</b>\n\nAmount: <b>' + qty + ' ' + symbol + '</b>\nNetwork: ' + (network || 'ERC20') + '\nAddress: <code>' + address.slice(0,12) + '...</code>\nStatus: ✅ Processing');
    res.json({ portfolio: portObj, message: `${qty} ${symbol} sent to ${address.slice(0, 12)}...` });
  } catch (e) {
    console.error('[EXCHANGE] Crypto withdraw error:', e);
    res.status(500).json({ error: 'Withdrawal failed' });
  }
});

// GET TRANSACTIONS
app.get('/api/transactions', auth, (req, res) => {
  const txns = stmts.getTransactions.all(req.user.id);
  res.json({ transactions: txns.map(t => ({
    type: t.type,
    coinId: t.coin_id,
    coin: t.coin_symbol,
    qty: t.quantity,
    priceUsd: t.price_usd,
    xaf: t.amount_xaf,
    method: t.method,
    phone: t.phone,
    addr: t.address,
    network: t.network,
    status: t.status,
    date: t.created_at
  }))});
});

// ══════════════════════════════════════
// CHANGE PASSWORD
// ══════════════════════════════════════
app.post('/api/auth/change-password', auth, (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!newPassword || newPassword.length < 8) return res.status(400).json({ error: 'New password must be at least 8 characters' });
    
    const fullUser = stmts.findUserByEmail.get(req.user.email);
    if (!bcrypt.compareSync(currentPassword, fullUser.password_hash)) return res.status(401).json({ error: 'Current password is incorrect' });
    
    const newHash = bcrypt.hashSync(newPassword, 12);
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(newHash, req.user.id);
    
    res.json({ message: 'Password changed successfully' });
  } catch (e) {
    res.status(500).json({ error: 'Failed to change password' });
  }
});

// ══════════════════════════════════════
// TELEGRAM BOT INTEGRATION
// ══════════════════════════════════════
const TG_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '';
const TG_USERNAME = process.env.TELEGRAM_BOT_USERNAME || '';
const TG_API = `https://api.telegram.org/bot${TG_TOKEN}`;

// Telegram tables
db.exec(`
  CREATE TABLE IF NOT EXISTS telegram_links (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    code TEXT UNIQUE NOT NULL,
    chat_id TEXT,
    connected INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(user_id) REFERENCES users(id)
  );
`);

async function tgSend(chatId, text) {
  if (!TG_TOKEN || !chatId) return;
  try {
    await fetch(`${TG_API}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: 'HTML' })
    });
  } catch (e) { console.error('[TG] Send error:', e.message); }
}

// Send notification to user if connected
function notifyUser(userId, message) {
  const link = db.prepare('SELECT chat_id FROM telegram_links WHERE user_id = ? AND connected = 1').get(userId);
  if (link && link.chat_id) tgSend(link.chat_id, message);
}

// Generate connect link
app.post('/api/telegram/connect', auth, (req, res) => {
  try {
    if (!TG_TOKEN) return res.status(400).json({ error: 'Telegram bot not configured' });
    // Check if already connected
    const existing = db.prepare('SELECT * FROM telegram_links WHERE user_id = ? AND connected = 1').get(req.user.id);
    if (existing) return res.json({ connected: true, chatId: existing.chat_id });
    // Generate unique code
    const code = crypto.randomBytes(16).toString('hex');
    db.prepare('DELETE FROM telegram_links WHERE user_id = ? AND connected = 0').run(req.user.id);
    db.prepare('INSERT INTO telegram_links (user_id, code) VALUES (?, ?)').run(req.user.id, code);
    const botName = TG_USERNAME.replace('@', '');
    const link = `https://t.me/${botName}?start=${code}`;
    console.log(`[TG] Connect link for user ${req.user.id}: ${link}`);
    res.json({ link, code });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Check connection status
app.get('/api/telegram/status', auth, (req, res) => {
  const link = db.prepare('SELECT * FROM telegram_links WHERE user_id = ? AND connected = 1').get(req.user.id);
  res.json({ connected: !!link, chatId: link ? link.chat_id : null });
});

// Disconnect
app.post('/api/telegram/disconnect', auth, (req, res) => {
  db.prepare('DELETE FROM telegram_links WHERE user_id = ?').run(req.user.id);
  res.json({ disconnected: true });
});

// Telegram webhook (receives updates from Telegram)
app.post('/api/telegram/webhook', (req, res) => {
  try {
    const msg = req.body.message;
    if (!msg || !msg.text) return res.json({ ok: true });
    const chatId = msg.chat.id;
    const text = msg.text.trim();

    if (text.startsWith('/start ')) {
      const code = text.replace('/start ', '').trim();
      const link = db.prepare('SELECT * FROM telegram_links WHERE code = ? AND connected = 0').get(code);
      if (link) {
        db.prepare('UPDATE telegram_links SET chat_id = ?, connected = 1 WHERE id = ?').run(String(chatId), link.id);
        const user = db.prepare('SELECT full_name FROM users WHERE id = ?').get(link.user_id);
        tgSend(chatId, `✅ <b>Connected!</b>\n\nHello ${user ? user.full_name : 'there'}! Your CryptoxCore account is now linked.\n\nYou'll receive notifications for:\n• Deposits & withdrawals\n• Buy & sell orders\n• Security alerts\n• Price alerts`);
        console.log(`[TG] User ${link.user_id} connected, chatId=${chatId}`);
      } else {
        tgSend(chatId, '❌ Invalid or expired link. Please generate a new one from your CryptoxCore profile.');
      }
    } else if (text === '/start') {
      tgSend(chatId, `👋 Welcome to CryptoxCore Bot!\n\nTo connect your account, go to your Profile page on cryptoxcore.com and click "Connect Telegram".`);
    } else if (text === '/balance') {
      const link = db.prepare('SELECT user_id FROM telegram_links WHERE chat_id = ? AND connected = 1').get(String(chatId));
      if (link) {
        const user = db.prepare('SELECT full_name, balance_xaf FROM users WHERE id = ?').get(link.user_id);
        if (user) tgSend(chatId, `💰 <b>${user.full_name}</b>\nBalance: <b>${Math.round(user.balance_xaf).toLocaleString()} XAF</b>`);
      } else {
        tgSend(chatId, '❌ Account not linked. Connect from your CryptoxCore profile first.');
      }
    } else if (text === '/help') {
      tgSend(chatId, `🤖 <b>CryptoxCore Bot Commands</b>\n\n/balance — Check your balance\n/help — Show this menu\n\nYou'll automatically receive notifications for all account activity.`);
    }
    res.json({ ok: true });
  } catch (e) {
    console.error('[TG] Webhook error:', e);
    res.json({ ok: true });
  }
});

// Set Telegram webhook on startup
if (TG_TOKEN) {
  setTimeout(async () => {
    try {
      const whUrl = 'https://cryptoxcore.com/api/telegram/webhook';
      const r = await fetch(`${TG_API}/setWebhook`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: whUrl })
      });
      const d = await r.json();
      console.log(`[TG] Webhook set: ${d.ok ? '✅' : '❌'} ${d.description || ''}`);
    } catch (e) { console.error('[TG] Webhook setup error:', e.message); }
  }, 5000);
}

// ══════════════════════════════════════
// FAPSHI PAYMENT INTEGRATION
// ══════════════════════════════════════
const FAPSHI_USER = process.env.FAPSHI_API_USER || '';
const FAPSHI_KEY = process.env.FAPSHI_API_KEY || '';
const FAPSHI_BASE = FAPSHI_KEY.startsWith('FAK_TEST') ? 'https://sandbox.fapshi.com' : 'https://live.fapshi.com';

async function fapshiRequest(endpoint, body, method = 'POST') {
  const opts = { method, headers: { 'Content-Type': 'application/json', 'apiuser': FAPSHI_USER, 'apikey': FAPSHI_KEY } };
  if (body && method !== 'GET') opts.body = JSON.stringify(body);
  const res = await fetch(`${FAPSHI_BASE}${endpoint}`, opts);
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || 'Fapshi API error');
  return data;
}

// Initiate Fapshi payment (redirect to checkout)
app.post('/api/fapshi/initiate', auth, (req, res) => {
  (async () => {
    try {
      const { amount, note } = req.body;
      const amt = parseInt(amount);
      if (!amt || amt < 100) return res.status(400).json({ error: 'Minimum 100 XAF' });

      const data = await fapshiRequest('/initiate-pay', {
        amount: amt,
        email: req.user.email,
        userId: String(req.user.id),
        externalId: 'DEP_' + req.user.id + '_' + Date.now(),
        redirectUrl: 'https://cryptoxcore.com/deposit',
        message: note || 'CryptoxCore Deposit'
      });

      if (!data.link || !data.transId) throw new Error('No payment link returned');

      // Store pending deposit
      db.prepare(
        "INSERT INTO transactions (user_id, type, coin_id, coin_symbol, quantity, price_usd, amount_xaf, method, phone, address, network, status) VALUES (?, 'deposit', null, null, null, null, ?, ?, null, null, null, 'pending')"
      ).run(req.user.id, amt, 'fapshi:' + data.transId);

      console.log(`[FAPSHI] Payment initiated: ${amt} XAF, transId=${data.transId}`);
      res.json({ link: data.link, transId: data.transId });
    } catch (e) {
      console.error('[FAPSHI] Initiate error:', e.message);
      res.status(500).json({ error: e.message });
    }
  })();
});

// Check Fapshi payment status
app.get('/api/fapshi/status/:transId', auth, (req, res) => {
  (async () => {
    try {
      const data = await fapshiRequest(`/payment-status/${req.params.transId}`, null, 'GET');
      const status = data.status || 'PENDING';

      // If successful, credit user
      if (status === 'SUCCESSFUL') {
        const tx = db.prepare("SELECT * FROM transactions WHERE method = ? AND user_id = ? AND status = 'pending'").get('fapshi:' + req.params.transId, req.user.id);
        if (tx) {
          const amt = tx.amount_xaf;
          stmts.updateBalance.run(req.user.balance_xaf + amt, req.user.id);
          db.prepare("UPDATE transactions SET status = 'completed' WHERE id = ?").run(tx.id);
          notifyUser(req.user.id, '💰 <b>Deposit Confirmed!</b>\n\nAmount: <b>' + amt + ' XAF</b>\nMethod: Fapshi Pay\nStatus: ✅ Completed');console.log(`[FAPSHI] Deposit credited: ${amt} XAF for user ${req.user.id}`);
        }
      }

      res.json({ status, transId: req.params.transId, amount: data.amount });
    } catch (e) {
      console.error('[FAPSHI] Status error:', e.message);
      res.status(500).json({ error: e.message, status: 'PENDING' });
    }
  })();
});

// Fapshi webhook (for instant notification)
app.post('/api/fapshi/webhook', (req, res) => {
  try {
    const { transId, status } = req.body;
    console.log(`[FAPSHI WEBHOOK] transId=${transId} status=${status}`);

    if (status === 'SUCCESSFUL' && transId) {
      const tx = db.prepare("SELECT t.*, u.balance_xaf FROM transactions t JOIN users u ON t.user_id = u.id WHERE t.method = ? AND t.status = 'pending'").get('fapshi:' + transId);
      if (tx) {
        stmts.updateBalance.run(tx.balance_xaf + tx.amount_xaf, tx.user_id);
        db.prepare("UPDATE transactions SET status = 'completed' WHERE id = ?").run(tx.id);
        notifyUser(tx.user_id, '💰 <b>Deposit Received!</b>\n\nAmount: <b>' + Math.round(tx.amount_xaf).toLocaleString() + ' XAF</b>\nMethod: Fapshi Pay\nStatus: ✅ Completed');console.log(`[FAPSHI WEBHOOK] Auto-credited ${tx.amount_xaf} XAF to user ${tx.user_id}`);
      }
    }
    res.json({ received: true });
  } catch (e) {
    console.error('[FAPSHI WEBHOOK] Error:', e);
    res.json({ received: true });
  }
});

// ══════════════════════════════════════
// CRYPTO DEPOSIT (Binance Integration)
// ══════════════════════════════════════

// DB table for crypto deposits
db.exec(`
  CREATE TABLE IF NOT EXISTS crypto_deposits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    coin TEXT NOT NULL,
    network TEXT NOT NULL,
    amount REAL,
    address TEXT,
    status TEXT DEFAULT 'pending',
    tx_hash TEXT,
    confirmations INTEGER DEFAULT 0,
    required_confirmations INTEGER DEFAULT 3,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(user_id) REFERENCES users(id)
  );
`);

// Get available networks for a coin
app.get('/api/crypto/networks/:coin', auth, (req, res) => {
  const coin = req.params.coin.toUpperCase();
  const networks = COIN_NETWORKS[coin];
  if (!networks) return res.status(400).json({ error: 'Unsupported coin: ' + coin });
  res.json({ coin, networks });
});

// Get deposit address from Binance
app.post('/api/crypto/deposit-address', auth, (req, res) => {
  (async () => {
    try {
      const { coin, network } = req.body;
      if (!coin || !network) return res.status(400).json({ error: 'Coin and network required' });
      
      const coinUp = coin.toUpperCase();
      const nets = COIN_NETWORKS[coinUp];
      if (!nets) return res.status(400).json({ error: 'Unsupported coin' });
      
      const netInfo = nets.find(n => n.network === network);
      if (!netInfo) return res.status(400).json({ error: 'Unsupported network for ' + coinUp });
      
      // Get deposit address from Binance
      const data = await binanceRequest('/sapi/v1/capital/deposit/address', {
        coin: coinUp,
        network: network
      });
      
      if (!data.address) throw new Error('No address returned from Binance');
      
      console.log(`[CRYPTO] Deposit address for ${coinUp} (${network}): ${data.address}`);
      
      res.json({
        coin: coinUp,
        network: network,
        networkName: netInfo.name,
        address: data.address,
        tag: data.tag || null,
        minDeposit: netInfo.minDeposit,
        url: data.url || null
      });
    } catch (e) {
      console.error('[CRYPTO] Deposit address error:', e.message);
      res.status(500).json({ error: 'Failed to get deposit address: ' + e.message });
    }
  })();
});

// Create deposit invoice (track it)
app.post('/api/crypto/create-invoice', auth, (req, res) => {
  try {
    const { coin, network, amount, address } = req.body;
    if (!coin || !network || !amount || !address) return res.status(400).json({ error: 'Missing fields' });
    
    const coinUp = coin.toUpperCase();
    const nets = COIN_NETWORKS[coinUp];
    const netInfo = nets ? nets.find(n => n.network === network) : null;
    const reqConf = coinUp === 'BTC' ? 3 : coinUp === 'ETH' ? 12 : coinUp === 'SOL' ? 1 : 15;
    
    const result = db.prepare(
      'INSERT INTO crypto_deposits (user_id, coin, network, amount, address, required_confirmations) VALUES (?, ?, ?, ?, ?, ?)'
    ).run(req.user.id, coinUp, network, parseFloat(amount), address, reqConf);
    
    console.log(`[CRYPTO] Invoice #${result.lastInsertRowid}: ${amount} ${coinUp} on ${network}`);
    
    res.json({
      invoiceId: result.lastInsertRowid,
      coin: coinUp,
      network,
      networkName: netInfo ? netInfo.name : network,
      amount: parseFloat(amount),
      address,
      status: 'pending',
      confirmations: 0,
      requiredConfirmations: reqConf
    });
  } catch (e) {
    console.error('[CRYPTO] Invoice error:', e);
    res.status(500).json({ error: 'Failed to create invoice' });
  }
});

// Check deposit status (polls Binance for recent deposits)
app.get('/api/crypto/check-deposit/:invoiceId', auth, (req, res) => {
  (async () => {
    try {
      const invoice = db.prepare('SELECT * FROM crypto_deposits WHERE id = ? AND user_id = ?').get(
        req.params.invoiceId, req.user.id
      );
      if (!invoice) return res.status(404).json({ error: 'Invoice not found' });
      
      if (invoice.status === 'completed') {
        return res.json({
          status: 'completed',
          confirmations: invoice.confirmations,
          requiredConfirmations: invoice.required_confirmations,
          txHash: invoice.tx_hash
        });
      }
      
      // Check Binance deposit history
      const deposits = await binanceRequest('/sapi/v1/capital/deposit/hisrec', {
        coin: invoice.coin,
        status: 1, // 1 = success, 0 = pending, 6 = credited
        startTime: new Date(invoice.created_at).getTime() - 60000,
        limit: 20
      });
      
      // Find matching deposit
      let matched = null;
      if (Array.isArray(deposits)) {
        matched = deposits.find(d => {
          const amountMatch = Math.abs(parseFloat(d.amount) - invoice.amount) < 0.0001 * invoice.amount;
          const networkMatch = d.network === invoice.network;
          return amountMatch && networkMatch;
        });
      }
      
      if (matched) {
        const confirmations = matched.confirmTimes ? parseInt(matched.confirmTimes.split('/')[0]) : 0;
        const reqConf = matched.confirmTimes ? parseInt(matched.confirmTimes.split('/')[1]) : invoice.required_confirmations;
        const isComplete = matched.status === 1;
        
        // Update invoice
        db.prepare(
          "UPDATE crypto_deposits SET status = ?, confirmations = ?, required_confirmations = ?, tx_hash = ?, updated_at = datetime('now') WHERE id = ?"
        ).run(isComplete ? 'completed' : 'confirming', confirmations, reqConf, matched.txId || null, invoice.id);
        
        // If completed, credit user
        if (isComplete && invoice.status !== 'completed') {
          const price = getCoinPrice(invoice.coin.toLowerCase()) || 0;
          const xafValue = invoice.amount * price * XAF_RATE;
          
          // Add to portfolio
          stmts.upsertPortfolio.run(req.user.id, invoice.coin.toLowerCase(), invoice.amount, invoice.amount);
          
          // Record transaction
          stmts.addTransaction.run(
            req.user.id, 'crypto_dep', invoice.coin.toLowerCase(), invoice.coin,
            invoice.amount, price, xafValue, null, null, invoice.address, invoice.network, 'completed'
          );
          
          notifyUser(req.user.id, '₿ <b>Crypto Deposit Confirmed!</b>\n\nAmount: <b>' + invoice.amount + ' ' + invoice.coin + '</b>\nNetwork: ' + invoice.network + '\nStatus: ✅ Confirmed');console.log(`[CRYPTO] Deposit credited: ${invoice.amount} ${invoice.coin} for user ${req.user.id}`);
        }
        
        return res.json({
          status: isComplete ? 'completed' : 'confirming',
          confirmations,
          requiredConfirmations: reqConf,
          txHash: matched.txId || null
        });
      }
      
      // No match yet
      res.json({
        status: 'pending',
        confirmations: 0,
        requiredConfirmations: invoice.required_confirmations,
        txHash: null
      });
    } catch (e) {
      console.error('[CRYPTO] Check deposit error:', e.message);
      // Return current DB state on API error
      const invoice = db.prepare('SELECT * FROM crypto_deposits WHERE id = ?').get(req.params.invoiceId);
      res.json({
        status: invoice ? invoice.status : 'pending',
        confirmations: invoice ? invoice.confirmations : 0,
        requiredConfirmations: invoice ? invoice.required_confirmations : 3,
        txHash: invoice ? invoice.tx_hash : null,
        error: e.message
      });
    }
  })();
});

// Get user's crypto deposits
app.get('/api/crypto/deposits', auth, (req, res) => {
  const deps = db.prepare('SELECT * FROM crypto_deposits WHERE user_id = ? ORDER BY created_at DESC LIMIT 50').all(req.user.id);
  res.json({ deposits: deps });
});

// ══════════════════════════════════════
// SUPPORT TICKET SYSTEM
// ══════════════════════════════════════
db.exec(`
  CREATE TABLE IF NOT EXISTS tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    subject TEXT NOT NULL,
    category TEXT DEFAULT 'general',
    status TEXT DEFAULT 'open',
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(user_id) REFERENCES users(id)
  );
  CREATE TABLE IF NOT EXISTS ticket_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id INTEGER NOT NULL,
    sender TEXT NOT NULL,
    message TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(ticket_id) REFERENCES tickets(id)
  );
`);

// Create ticket
app.post('/api/support/create', auth, (req, res) => {
  try {
    const { subject, message, category } = req.body;
    if (!subject || subject.length < 3) return res.status(400).json({ error: 'Subject too short' });
    if (!message || message.length < 10) return res.status(400).json({ error: 'Message too short' });
    
    const result = db.prepare('INSERT INTO tickets (user_id, subject, category) VALUES (?, ?, ?)').run(
      req.user.id, subject, category || 'general'
    );
    db.prepare('INSERT INTO ticket_messages (ticket_id, sender, message) VALUES (?, ?, ?)').run(
      result.lastInsertRowid, 'user', message
    );
    
    // Get all messages for this ticket
    const msgs = db.prepare('SELECT sender as "from", message as text, created_at as date FROM ticket_messages WHERE ticket_id = ? ORDER BY created_at ASC').all(result.lastInsertRowid);
    
    console.log(`[SUPPORT] New ticket #${result.lastInsertRowid}: ${subject}`);
    res.json({ ticket: {
      id: result.lastInsertRowid,
      subject,
      category: category || 'general',
      status: 'open',
      message,
      messages: msgs,
      date: new Date().toISOString()
    }});
  } catch (e) {
    console.error('[SUPPORT] Create error:', e);
    res.status(500).json({ error: 'Failed to create ticket' });
  }
});

// Get all tickets for user
app.get('/api/support/tickets', auth, (req, res) => {
  try {
    const tix = db.prepare('SELECT * FROM tickets WHERE user_id = ? ORDER BY updated_at DESC').all(req.user.id);
    const result = tix.map(t => {
      const msgs = db.prepare('SELECT sender as "from", message as text, created_at as date FROM ticket_messages WHERE ticket_id = ? ORDER BY created_at ASC').all(t.id);
      return {
        id: t.id,
        subject: t.subject,
        category: t.category,
        status: t.status,
        message: msgs.length > 0 ? msgs[0].text : '',
        messages: msgs,
        date: t.created_at
      };
    });
    res.json({ tickets: result });
  } catch (e) {
    console.error('[SUPPORT] List error:', e);
    res.status(500).json({ error: 'Failed to load tickets' });
  }
});

// Reply to ticket
app.post('/api/support/reply', auth, (req, res) => {
  try {
    const { ticketId, message } = req.body;
    if (!message || !message.trim()) return res.status(400).json({ error: 'Message required' });
    
    const ticket = db.prepare('SELECT * FROM tickets WHERE id = ? AND user_id = ?').get(ticketId, req.user.id);
    if (!ticket) return res.status(404).json({ error: 'Ticket not found' });
    if (ticket.status === 'closed') return res.status(400).json({ error: 'Ticket is closed' });
    
    db.prepare('INSERT INTO ticket_messages (ticket_id, sender, message) VALUES (?, ?, ?)').run(ticketId, 'user', message.trim());
    db.prepare("UPDATE tickets SET updated_at = datetime('now'), status = 'open' WHERE id = ?").run(ticketId);
    
    console.log(`[SUPPORT] Reply on ticket #${ticketId}`);
    res.json({ message: { from: 'user', text: message.trim(), date: new Date().toISOString() }, status: 'open' });
  } catch (e) {
    console.error('[SUPPORT] Reply error:', e);
    res.status(500).json({ error: 'Failed to send reply' });
  }
});

// ══════════════════════════════════════
// ADMIN PANEL API
// ══════════════════════════════════════

// Admin middleware (rate limited + logged)
const adminEmails = ['no-reply@cryptoxcore.com'];
const adminAuth = (req, res, next) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  const ip = getIP(req);
  if (!token) return res.status(401).json({ error: 'No token' });
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const user = stmts.findUserById.get(decoded.userId);
    if (!user || !adminEmails.includes(user.email)) {
      secLog('ADMIN_ACCESS_DENIED', { ip, userId: decoded.userId });
      return res.status(403).json({ error: 'Admin access required' });
    }
    secLog('ADMIN_ACCESS', { ip, email: user.email, path: req.path });
    req.user = user;
    next();
  } catch (e) { return res.status(401).json({ error: 'Invalid token' }); }
};

// Admin: Dashboard stats
app.get('/api/admin/stats', adminAuth, (req, res) => {
  try {
    const totalUsers = db.prepare('SELECT COUNT(*) as c FROM users').get().c;
    const totalBal = db.prepare('SELECT COALESCE(SUM(balance_xaf),0) as s FROM users').get().s;
    const totalTx = db.prepare('SELECT COUNT(*) as c FROM transactions').get().c;
    const todayTx = db.prepare("SELECT COUNT(*) as c FROM transactions WHERE created_at >= date('now')").get().c;
    const totalDeposits = db.prepare("SELECT COALESCE(SUM(amount_xaf),0) as s FROM transactions WHERE type='deposit'").get().s;
    const totalWithdraws = db.prepare("SELECT COALESCE(SUM(amount_xaf),0) as s FROM transactions WHERE type='withdraw'").get().s;
    const totalBuys = db.prepare("SELECT COUNT(*) as c FROM transactions WHERE type='buy'").get().c;
    const totalSells = db.prepare("SELECT COUNT(*) as c FROM transactions WHERE type='sell'").get().c;
    const openTickets = db.prepare("SELECT COUNT(*) as c FROM tickets WHERE status IN ('open','pending')").get().c;
    const recentUsers = db.prepare("SELECT COUNT(*) as c FROM users WHERE created_at >= date('now','-7 days')").get().c;
    const cryptoDeps = db.prepare("SELECT COUNT(*) as c FROM crypto_deposits").get().c;
    const pendingDeps = db.prepare("SELECT COUNT(*) as c FROM crypto_deposits WHERE status='pending'").get().c;
    res.json({ totalUsers, totalBal, totalTx, todayTx, totalDeposits, totalWithdraws, totalBuys, totalSells, openTickets, recentUsers, cryptoDeps, pendingDeps });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Admin: All users
app.get('/api/admin/users', adminAuth, (req, res) => {
  try {
    const users = db.prepare('SELECT id, full_name, email, phone, balance_xaf, created_at, last_login, is_verified, tfa_enabled FROM users ORDER BY created_at DESC').all();
    res.json({ users });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Admin: User detail
app.get('/api/admin/users/:id', adminAuth, (req, res) => {
  try {
    const user = db.prepare('SELECT id, full_name, email, phone, balance_xaf, created_at, last_login, is_verified, tfa_enabled FROM users WHERE id = ?').get(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    const portfolio = db.prepare('SELECT coin_id, quantity FROM portfolio WHERE user_id = ? AND quantity > 0').all(req.params.id);
    const transactions = db.prepare('SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50').all(req.params.id);
    const tickets = db.prepare('SELECT * FROM tickets WHERE user_id = ? ORDER BY created_at DESC').all(req.params.id);
    res.json({ user, portfolio, transactions, tickets });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Admin: Update user balance
app.post('/api/admin/users/:id/balance', adminAuth, (req, res) => {
  try {
    const { amount, action } = req.body; // action: 'set', 'add', 'subtract'
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    let newBal = user.balance_xaf;
    if (action === 'set') newBal = parseFloat(amount);
    else if (action === 'add') newBal += parseFloat(amount);
    else if (action === 'subtract') newBal = Math.max(0, newBal - parseFloat(amount));
    stmts.updateBalance.run(newBal, user.id);
    stmts.addTransaction.run(user.id, 'admin_adj', null, null, null, null, parseFloat(amount), 'Admin adjustment: ' + action, null, null, null, 'completed');
    console.log(`[ADMIN] Balance ${action}: ${amount} XAF for user ${user.id} (${user.email})`);
    res.json({ balance: newBal, message: `Balance updated to ${newBal} XAF` });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Admin: Verify/ban user
app.post('/api/admin/users/:id/status', adminAuth, (req, res) => {
  try {
    const { action } = req.body; // 'verify', 'unverify'
    const val = action === 'verify' ? 1 : 0;
    db.prepare('UPDATE users SET is_verified = ? WHERE id = ?').run(val, req.params.id);
    res.json({ message: `User ${action === 'verify' ? 'verified' : 'unverified'}` });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Admin: All transactions
app.get('/api/admin/transactions', adminAuth, (req, res) => {
  try {
    const txns = db.prepare(`
      SELECT t.*, u.full_name, u.email 
      FROM transactions t JOIN users u ON t.user_id = u.id 
      ORDER BY t.created_at DESC LIMIT 200
    `).all();
    res.json({ transactions: txns });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Admin: All crypto deposits
app.get('/api/admin/crypto-deposits', adminAuth, (req, res) => {
  try {
    const deps = db.prepare(`
      SELECT cd.*, u.full_name, u.email 
      FROM crypto_deposits cd JOIN users u ON cd.user_id = u.id 
      ORDER BY cd.created_at DESC LIMIT 100
    `).all();
    res.json({ deposits: deps });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Admin: All tickets (already exists but enhance)
app.get('/api/admin/tickets', adminAuth, (req, res) => {
  try {
    const tix = db.prepare(`
      SELECT t.*, u.full_name, u.email 
      FROM tickets t JOIN users u ON t.user_id = u.id 
      ORDER BY t.updated_at DESC
    `).all();
    const result = tix.map(t => {
      const msgs = db.prepare('SELECT sender as "from", message as text, created_at as date FROM ticket_messages WHERE ticket_id = ? ORDER BY created_at ASC').all(t.id);
      return { id: t.id, subject: t.subject, category: t.category, status: t.status, userName: t.full_name, userEmail: t.email, messages: msgs, date: t.created_at, updated: t.updated_at };
    });
    res.json({ tickets: result });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Admin: Reply to ticket
app.post('/api/admin/tickets/:id/reply', adminAuth, (req, res) => {
  try {
    const { message, status } = req.body;
    if (!message || !message.trim()) return res.status(400).json({ error: 'Message required' });
    db.prepare('INSERT INTO ticket_messages (ticket_id, sender, message) VALUES (?, ?, ?)').run(req.params.id, 'admin', message.trim());
    const newStatus = status || 'pending';
    db.prepare("UPDATE tickets SET status = ?, updated_at = datetime('now') WHERE id = ?").run(newStatus, req.params.id);
    console.log(`[ADMIN] Reply on ticket #${req.params.id}`);
    res.json({ success: true, status: newStatus });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Admin: Close ticket
app.post('/api/admin/tickets/:id/close', adminAuth, (req, res) => {
  try {
    db.prepare("UPDATE tickets SET status = 'closed', updated_at = datetime('now') WHERE id = ?").run(req.params.id);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Admin: Platform settings
app.get('/api/admin/settings', adminAuth, (req, res) => {
  try {
    db.exec("CREATE TABLE IF NOT EXISTS platform_settings (key TEXT PRIMARY KEY, value TEXT)");
    const rows = db.prepare('SELECT key, value FROM platform_settings').all();
    const settings = {};
    rows.forEach(r => { settings[r.key] = r.value; });
    res.json({ settings: { xafRate: settings.xaf_rate || '530', minDeposit: settings.min_deposit || '100', minWithdraw: settings.min_withdraw || '500', maintenance: settings.maintenance || 'false', announcement: settings.announcement || '', ...settings } });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Admin: Update settings
app.post('/api/admin/settings', adminAuth, (req, res) => {
  try {
    db.exec("CREATE TABLE IF NOT EXISTS platform_settings (key TEXT PRIMARY KEY, value TEXT)");
    const { key, value } = req.body;
    db.prepare('INSERT INTO platform_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = ?').run(key, value, value);
    console.log(`[ADMIN] Setting updated: ${key} = ${value}`);
    res.json({ success: true });

// ═══ PROMO BANNER ═══
let promoBanner = "With Fauscrypto.com       Buy and Sell Your Crypto With Fauscrypto.com";
try { promoBanner = require('fs').readFileSync('/opt/cryptoxcore/promo.txt','utf8').trim() || promoBanner; } catch {}

app.get('/api/promo', (req, res) => {
  res.json({ promo: promoBanner });
});

app.post('/api/admin/promo', adminAuth, (req, res) => {
  const { text } = req.body;
  if (!text || !text.trim()) return res.status(400).json({ error: 'Promo text required' });
  promoBanner = text.trim();
  try { require('fs').writeFileSync('/opt/cryptoxcore/promo.txt', promoBanner); } catch {}
  console.log('[ADMIN] Promo updated:', promoBanner);
  res.json({ success: true, promo: promoBanner });
});

  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Serve admin panel
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});



// ══════════════════════════════════════
// GLOBAL ERROR HANDLER — prevents stack trace leakage
// ══════════════════════════════════════
app.use((err, req, res, next) => {
  const ip = getIP(req);
  secLog('SERVER_ERROR', { ip, path: req.path, error: err.message });
  res.status(err.status || 500).json({ error: 'Something went wrong. Please try again.' });
});

// ══════════════════════════════════════
// SERVE FRONTEND — Multi-page routing
// ══════════════════════════════════════

// Auth pages
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});
app.get('/register', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'register.html'));
});
app.get('/signup', (req, res) => {
  res.redirect(301, '/register');
});
app.get('/forgot-password', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'forgot-password.html'));
});

// Dashboard (all authenticated routes)
const dashboardRoutes = ['/dashboard', '/wallet', '/exchange', '/deposit', '/withdraw',
  '/crypto-deposit', '/crypto-withdraw', '/transactions', '/profile', '/support', '/settings'];
dashboardRoutes.forEach(route => {
  app.get(route, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
  });
});
app.get('/exchange/:action/:coin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

// Landing page (home)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Catch-all fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ══════════════════════════════════════
// START SERVER
// ══════════════════════════════════════
app.listen(PORT, '0.0.0.0', () => {
  console.log(`
╔══════════════════════════════════════════╗
║   CryptoxCore Backend Server v1.0        ║
║   Running on port ${PORT}                    ║
║   Database: SQLite (cryptoxcore.db)      ║
║   Auth: bcrypt + JWT                     ║
║   Prices: CoinGecko (30s refresh)        ║
╚══════════════════════════════════════════╝
  `);
});
