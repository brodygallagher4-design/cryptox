var MO=document.getElementById('authModal');
function mShow(t,s){MO.querySelector('.sp').style.display='block';MO.querySelector('.ok').className='ok';MO.querySelector('.tt').textContent=t;MO.querySelector('.tt').style.color='#111827';MO.querySelector('.sb').textContent=s;MO.querySelector('.dots').style.display='flex';MO.classList.add('on');}
function mOk(t,s){return new Promise(function(r){MO.querySelector('.sp').style.display='none';MO.querySelector('.ok').className='ok on';MO.querySelector('.tt').textContent=t;MO.querySelector('.tt').style.color='#059669';MO.querySelector('.sb').textContent=s;MO.querySelector('.dots').style.display='none';setTimeout(function(){MO.classList.remove('on');r();},1300);});}
function mHide(){MO.classList.remove('on');}
function showErr(m){var e=document.getElementById('formErr');if(e){e.className='err show';e.textContent=m;}}
function hideErr(){var e=document.getElementById('formErr');if(e){e.className='err';e.textContent='';}}
